import pygame as pg
import pytmx

from src.utils import load_tmx, Position, GameSettings, PositionCamera, Teleport

class Map:
    # Map Properties
    path_name: str
    tmxdata: pytmx.TiledMap
    # Position Argument
    spawn: Position
    teleporters: list[Teleport]
    # Rendering Properties
    _surface: pg.Surface
    _collision_map: list[pg.Rect]

    # def __init__(self, path: str, tp: list[Teleport], spawn: Position):
    def __init__(self, path: str, tp: list[Teleport]):
        self.path_name = path
        self.tmxdata = load_tmx(path)
        # self.spawn = spawn
        self.teleporters = tp

        pixel_w = self.tmxdata.width * GameSettings.TILE_SIZE
        pixel_h = self.tmxdata.height * GameSettings.TILE_SIZE

        # Prebake the map
        self._surface = pg.Surface((pixel_w, pixel_h), pg.SRCALPHA)
        self._render_all_layers(self._surface)
        # Prebake the collision map
        self._collision_map = self._create_collision_map()
        self._bush_map = self._create_bush_map()

    def update(self, dt: float):
        return
    def query_bush_prob(self, player_pos: Position):
        return {"pikachu": 30, "bulbasaur":70}, 50  # Placeholder implementation

    def draw(self, screen: pg.Surface, camera: PositionCamera):
        screen.blit(self._surface, camera.transform_position(Position(0, 0)))
        
        # Draw the hitboxes collision map
        if GameSettings.DRAW_HITBOXES:
            for rect in self._collision_map:
                pg.draw.rect(screen, (255, 0, 0), camera.transform_rect(rect), 1)
            for rect in self._bush_map:
                r = rect.copy()
                r.left += 4
                r.top += 4
                pg.draw.rect(screen, (0, 0, 255), camera.transform_rect(r), 1)
        
    def check_bush(self, rect: pg.Rect) -> bool:
        
        return any(r.collidepoint(rect.center) for r in self._bush_map)

    def check_collision(self, rect: pg.Rect) -> bool:
        '''
        [TODO HACKATHON 4]
        Return True if collide if rect param collide with self._collision_map
        Hint: use API colliderect and iterate each rectangle to check
        '''
        # print(  "Checking collision for rect:", rect  )
        return any(rect.colliderect(r) for r in self._collision_map)
        
    def check_teleport(self, pos: Position) -> Teleport | None:
        for tp in self.teleporters:
            # if tp.get_hitbox().collidepoint(pos.x, pos.y):
                # return tp
            halfGSTZ = GameSettings.TILE_SIZE // 2
            hitbox = pg.Rect(tp.pos.x, tp.pos.y, GameSettings.TILE_SIZE, GameSettings.TILE_SIZE)
            if hitbox.collidepoint(pos.x + halfGSTZ, pos.y + halfGSTZ):
                return tp
        return None

    def _render_all_layers(self, target: pg.Surface) -> None:
        for layer in self.tmxdata.visible_layers:
            if isinstance(layer, pytmx.TiledTileLayer):
                self._render_tile_layer(target, layer)
            # elif isinstance(layer, pytmx.TiledImageLayer) and layer.image:
            #     target.blit(layer.image, (layer.x or 0, layer.y or 0))
 
    def _render_tile_layer(self, target: pg.Surface, layer: pytmx.TiledTileLayer) -> None:
        for x, y, gid in layer:
            if gid == 0:
                continue
            image = self.tmxdata.get_tile_image_by_gid(gid)
            if image is None:
                continue

            # Save tile 81 for inspection
            # if gid == 81:
            #     original_image = self.tmxdata.get_tile_image_by_gid(gid)
            #     scaled_for_save = pg.transform.scale(original_image, (GameSettings.TILE_SIZE * 8, GameSettings.TILE_SIZE * 8))
            #     pg.image.save(scaled_for_save, "tile_81.png")
            #     print(f"Saved GID 81 tile at position ({x}, {y})")

            image = pg.transform.scale(image, (GameSettings.TILE_SIZE, GameSettings.TILE_SIZE))
            target.blit(image, (x * GameSettings.TILE_SIZE, y * GameSettings.TILE_SIZE))
    
    def _create_collision_map(self) -> list[pg.Rect]:
        rects = []
        for layer in self.tmxdata.visible_layers:
            if isinstance(layer, pytmx.TiledTileLayer) and ("collision" in layer.name.lower() or "house" in layer.name.lower()):
                for x, y, gid in layer:
                    if gid != 0:
                        '''
                        [TODO HACKATHON 4]
                        rects.append(pg.Rect(...))
                        Append the collision rectangle to the rects[] array
                        Remember scale the rectangle with the TILE_SIZE from settings
                        '''
                        rects.append(pg.Rect(
                            x * GameSettings.TILE_SIZE,
                            y * GameSettings.TILE_SIZE,
                            GameSettings.TILE_SIZE,
                            GameSettings.TILE_SIZE
                        ))
        return rects
    def _create_bush_map(self) -> list[pg.Rect]:
        rects = []
        for layer in self.tmxdata.visible_layers:
            if isinstance(layer, pytmx.TiledTileLayer) and "pokemonbush" in layer.name.lower():
                for x, y, gid in layer:
                    if gid != 0:
                        rects.append(pg.Rect(
                            x * GameSettings.TILE_SIZE,
                            y * GameSettings.TILE_SIZE,
                            GameSettings.TILE_SIZE,
                            GameSettings.TILE_SIZE
                        ))
        return rects


    @classmethod
    def from_dict(cls, data: dict) -> "Map":
        tp = [Teleport.from_dict(t) for t in data["teleport"]]
        # pos = Position(data["player"]["x"] * GameSettings.TILE_SIZE, data["player"]["y"] * GameSettings.TILE_SIZE)
        # return cls(data["path"], tp, pos)
        return cls(data["path"], tp)

    def to_dict(self):
        print(self.teleporters)
        return {
            "path": self.path_name,
            "teleport": [t.to_dict() for t in self.teleporters],
            # "player": {
            #     "x": self.spawn.x // GameSettings.TILE_SIZE,
            #     "y": self.spawn.y // GameSettings.TILE_SIZE,
            # }
        }
